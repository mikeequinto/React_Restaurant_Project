import React from 'react'

export default class UserHelper extends Component {

  constructor(){
      this.userFullname: '',
      this.user
  }

  helloChandu(){
    console.log('Hello Chandu');
  }
}
