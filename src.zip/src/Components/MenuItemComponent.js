import React, {useState, useContext, useEffect}from 'react'
import firebase from '../firebase'

import {AuthContext} from '../Auth'

export default function HomeComponent(props) {

   const {currentUser} = useContext(AuthContext)

   const [rating, setRating] = useState(props.ramen.rating)

   const [userRating, setUserRating] = useState(5)

   const [ratings, setRatings] = useState([])

   //Données du ramen
   const dbRamen = firebase.firestore().collection('ramens')
   .doc(props.ramen.id)
   //Collection des ratings des utilisateurs
   const dbRatings = firebase.firestore().collection('ratings')
   .doc(props.ramen.id).collection('userRatings')

   useEffect(() => {
      const fetchData = async () => {

         const data = await dbRatings.get()
         setRatings(data.docs.map(doc => ({
            ...doc.data(),
            id: doc.id
         })))
      }
      fetchData()
   }, [])

   function handleChange(event) {
     setUserRating(event.target.value)
   }

   async function submitRating(event){
      event.preventDefault()
      try{
         //Sauvegarde du rating de l'utilisateur
         updateUserRating()
         //Calcul de la nouvelle moyenne des ratings du ramen
         calculateRamenRating()

      }catch(error){
         alert(error)
      }
   }

   function updateUserRating(){
      //Ajout du nouveau rating dans firestore
      dbRatings.doc(currentUser.id).set({
         rating: userRating
      })
      //Ajout du rating dans ratings
      setRatings(ratings =>[
         ...ratings,
         {
            id: currentUser.id,
            rating: userRating
         }
      ])
   }

   function calculateRamenRating(){
      let total = parseFloat(userRating)
      //Récupération des ratings du ramen
      ratings.map(rating => (
         total += parseFloat(rating.rating)
      ))
      //Calcul de la moyenne
      const newRating = total / (ratings.length + 1)
      //Mise à jour du nouveau rating du ramen
      updateRamenRating(newRating)
   }

   function updateRamenRating(newRating){
      //Mise à jour du rating du ramen
      setRating(newRating)
      //Mise à jour dans firestore
      dbRamen.update({
         rating: newRating
      })
   }

   function userAlreadyRated(){
      //Check si ratings contient l'id de l'utilisateur
      if(currentUser.id !== ''){
         return ratings
         .some(rating => currentUser.id === rating.id)
      }
      return true
   }

  return (
    <div>
      <h1>{props.ramen.name}</h1>
      <p> Price : {props.ramen.price}</p>
      <p>Rating : {rating}</p>
      {//L'utilisateur peut seulement rate une fois
       // et doit être connecté
         !userAlreadyRated() ?
         <div>
            <input
               type="number"
               id="userRating"
               value={userRating}
               onChange={handleChange}
            />
            <button onClick={submitRating}>submit</button>
         </div>
         : null
      }
    </div>
  );
}
