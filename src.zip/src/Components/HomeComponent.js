import React, { useContext } from 'react';



export default function HomeComponent() {

  return (
    <div>
      <h1>Home</h1>
    </div>
  );
}
