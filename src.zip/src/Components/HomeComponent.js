import React, { useContext } from 'react';

import { Redirect } from 'react-router-dom'
import {AuthContext} from '../Auth'

export default function HomeComponent() {

  const {currentUser} = useContext(AuthContext)

  return (
    <div>
      <h1>Home</h1>
    </div>
  );
}
