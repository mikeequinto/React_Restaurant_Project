import React, { useContext, useEffect, useState } from 'react';

import {AuthContext} from '../../Auth'
import app from '../../firebase'

import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import Box from '@material-ui/core/Box';

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
   },
   textField: {
      marginLeft: theme.spacing(1),
      marginRight: theme.spacing(1),
      width: 200,
   },
}));

export default function MyAccount() {

   const classes = useStyles();

   const {currentUser} = useContext(AuthContext)

   const [updatedUser, setUpdatedUser] = useState({
      name: '',
      email: '',
      password: '',
      password2: ''
   })

   useEffect(() => {

   }, []);

   function updateUser(){
      //Modification du user dans firebase authentication
      app.auth().onAuthStateChanged(function(user) {
        if (user) {
          // User is signed in.

        }
      });
   }

   function handleChange(evt){
      setUpdatedUser({
         [evt.target.id] : evt.target.value
      })
   }

  return (
    <div>
       <form>
         <TextField id="name" label="Name"
         value={currentUser.fullName} className={classes.textField}
         margin="normal" onChange={handleChange} />
         <TextField id="email" label="Email"
         value={currentUser.email} className={classes.textField}
         margin="normal" onChange={handleChange} />
         <TextField id="password" label="New Password" type="password"
         value="*******" className={classes.textField}
         margin="normal" onChange={handleChange} />
         <TextField id="password2" label="Confirm Password" type="password"
         value="*******" className={classes.textField}
         margin="normal" onChange={handleChange} />
         <br/>
         <Box m={3}>
            <Button onClick={updateUser} variant="contained">Update</Button>
         </Box>
       </form>
    </div>
  );
}
