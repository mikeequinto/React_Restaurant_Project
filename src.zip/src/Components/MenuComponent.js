import React, {useState, useEffect}from 'react'
import firebase from '../firebase'

import MenuItemComponent from './MenuItemComponent'

export default function HomeComponent() {

   const [ramens, setRamens] = useState([])

   useEffect(() => {
      const fetchData = async () => {
         const db = firebase.firestore()
         const data = await db.collection("ramens").get()
         setRamens(data.docs.map(doc => ({
            ...doc.data(),
            id: doc.id
         })))
      }
      fetchData()
   }, [])


  return (
    <div>
      <h1>Menu</h1>
      <ul>
         {ramens.map(ramen => (
            <li key={ramen.id}>
               <MenuItemComponent ramen={ramen}/>
            </li>
         ))}
      </ul>
    </div>
  );
}
